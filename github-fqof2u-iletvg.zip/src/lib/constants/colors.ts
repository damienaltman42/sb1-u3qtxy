export const PRESET_COLORS = [
  '#FF69B4', // Hot Pink
  '#9370DB', // Medium Purple
  '#FF1493', // Deep Pink
  '#8A2BE2', // Blue Violet
  '#DA70D6', // Orchid
  '#BA55D3', // Medium Orchid
  '#FF69B4', // Hot Pink
  '#9370DB', // Medium Purple
  '#FF1493', // Deep Pink
  '#8A2BE2', // Blue Violet
];